print('Hello Word!')

# this is a comment
# variables
first_name = "Everald"
last_name = "McKie"
total = 9.99
age = 99
found = False

print(first_name)
print(last_name)
print(total)

print(9 + 1) # sum
print("9" + "1") # str contactenation

# math
print(10 + 1)
print(10 -1)
print(10 * 10)
print(10 / 2)

# if

if(age < 100):
    print('dont worry you are young')
    print('still inside the if')
    print('still inside 2')
elif age ==100:
    print('congratulations on the century')
else:
    print("sorry buddy, you are getting old")

print('outside')

def say_hello():
    print('hello' + name)


# call fns
say_hello("billy")
say_hello("barry")
say_hello("baddy")


