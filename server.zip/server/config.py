developer = {
    "first": "sergio",
    "last": "Inunza",
    "age": 37,
    "email": "emckie@sdgki.edu",
    "hobbies": ["code", "gazing into the sunset thinking of that special lady"]
    "address": {
        "num": 741,
        "street": "evergreen",
        "city": "springfield"
    }
}